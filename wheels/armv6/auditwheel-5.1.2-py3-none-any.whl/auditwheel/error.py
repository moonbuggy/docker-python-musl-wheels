class AuditwheelException(Exception):
    pass


class InvalidLibc(AuditwheelException):
    pass
