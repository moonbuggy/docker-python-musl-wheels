
__author__ = "Inada Naoki <songofacandy@gmail.com>"
version_info = (2,1,1,'final',0)
__version__ = "2.1.1"
