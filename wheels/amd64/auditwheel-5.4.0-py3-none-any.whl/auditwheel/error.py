from __future__ import annotations


class AuditwheelException(Exception):
    pass


class InvalidLibc(AuditwheelException):
    pass
